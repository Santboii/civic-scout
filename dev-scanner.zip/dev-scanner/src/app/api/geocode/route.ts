import { NextRequest, NextResponse } from 'next/server'
import { isWithinChicago, normalizeAddress } from '@/lib/geocoder'

export const runtime = 'edge'

interface MapboxFeature {
  id: string
  place_name: string
  center: [number, number] // [lon, lat]
  context?: Array<{ id: string; text: string }>
}

export async function GET(request: NextRequest) {
  const { searchParams } = new URL(request.url)
  const query = searchParams.get('q')?.trim()

  if (!query || query.length < 3) {
    return NextResponse.json({ error: 'Query too short' }, { status: 400 })
  }

  const token = process.env.NEXT_PUBLIC_MAPBOX_TOKEN
  if (!token) {
    return NextResponse.json({ error: 'Mapbox token not configured' }, { status: 500 })
  }

  const params = new URLSearchParams({
    access_token: token,
    country: 'US',
    types: 'address',
    // Bias results toward Chicago
    proximity: '-87.6298,41.8781',
    bbox: '-87.940,41.644,-87.524,42.023',
    limit: '5',
  })

  const url = `https://api.mapbox.com/geocoding/v5/mapbox.places/${encodeURIComponent(query)}.json?${params}`
  const res = await fetch(url)

  if (!res.ok) {
    return NextResponse.json({ error: 'Geocoding failed' }, { status: 502 })
  }

  const data = await res.json()
  const features: MapboxFeature[] = data.features ?? []

  const results = features
    .map((f) => ({
      address: f.place_name,
      normalizedAddress: normalizeAddress(f.place_name),
      lat: f.center[1],
      lon: f.center[0],
    }))
    .filter((r) => isWithinChicago(r.lat, r.lon))

  return NextResponse.json({ results })
}
