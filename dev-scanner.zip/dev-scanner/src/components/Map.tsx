'use client'

import { useEffect, useRef, useState } from 'react'
import mapboxgl from 'mapbox-gl'
import 'mapbox-gl/dist/mapbox-gl.css'
import type { ClassifiedPermit } from '@/lib/permit-classifier'

interface MapProps {
  permits: ClassifiedPermit[]
  center: [number, number] // [lon, lat]
}

const SEVERITY_COLORS: Record<string, string> = {
  red: '#ef4444',
  yellow: '#f59e0b',
  green: '#22c55e',
}

export default function Map({ permits, center }: MapProps) {
  const mapContainer = useRef<HTMLDivElement>(null)
  const mapRef = useRef<mapboxgl.Map | null>(null)
  const markersRef = useRef<mapboxgl.Marker[]>([])

  useEffect(() => {
    if (!mapContainer.current || mapRef.current) return

    mapboxgl.accessToken = process.env.NEXT_PUBLIC_MAPBOX_TOKEN!

    mapRef.current = new mapboxgl.Map({
      container: mapContainer.current,
      style: 'mapbox://styles/mapbox/light-v11',
      center,
      zoom: 13,
    })

    mapRef.current.addControl(new mapboxgl.NavigationControl(), 'top-right')
  }, [center])

  useEffect(() => {
    const map = mapRef.current
    if (!map) return

    // Clear old markers
    markersRef.current.forEach((m) => m.remove())
    markersRef.current = []

    // Add search-center pin
    const el = document.createElement('div')
    el.className = 'w-5 h-5 rounded-full bg-blue-600 border-2 border-white shadow-lg'
    markersRef.current.push(new mapboxgl.Marker({ element: el }).setLngLat(center).addTo(map))

    // Add 2-mile radius circle via GeoJSON layer
    if (map.getSource('radius')) {
      ;(map.getSource('radius') as mapboxgl.GeoJSONSource).setData(createCircle(center, 3218))
    } else {
      map.on('load', () => addRadiusLayer(map, center))
    }
    if (map.isStyleLoaded()) addRadiusLayer(map, center)

    // Add permit markers
    permits.forEach((permit) => {
      const dot = document.createElement('div')
      dot.className = 'w-4 h-4 rounded-full border-2 border-white shadow cursor-pointer'
      dot.style.backgroundColor = SEVERITY_COLORS[permit.severity] ?? '#6b7280'

      const popup = new mapboxgl.Popup({ offset: 10, maxWidth: '280px' }).setHTML(`
        <div class="text-sm">
          <p class="font-semibold">${permit.address}</p>
          <p class="text-xs text-gray-500">${permit.permit_type}</p>
          <p class="mt-1">${permit.work_description?.slice(0, 100) ?? ''}${(permit.work_description?.length ?? 0) > 100 ? '…' : ''}</p>
          ${permit.reported_cost ? `<p class="mt-1 font-medium">$${permit.reported_cost.toLocaleString()}</p>` : ''}
          <span class="inline-block mt-1 px-2 py-0.5 rounded text-xs text-white" style="background:${SEVERITY_COLORS[permit.severity]}">${permit.severity.toUpperCase()}</span>
        </div>
      `)

      const marker = new mapboxgl.Marker({ element: dot })
        .setLngLat([permit.lon, permit.lat])
        .setPopup(popup)
        .addTo(map)

      markersRef.current.push(marker)
    })
  }, [permits, center])

  return <div ref={mapContainer} className="w-full h-full rounded-xl overflow-hidden" />
}

function addRadiusLayer(map: mapboxgl.Map, center: [number, number]) {
  const circleData = createCircle(center, 3218)
  if (map.getSource('radius')) {
    ;(map.getSource('radius') as mapboxgl.GeoJSONSource).setData(circleData)
    return
  }
  map.addSource('radius', { type: 'geojson', data: circleData })
  map.addLayer({
    id: 'radius-fill',
    type: 'fill',
    source: 'radius',
    paint: { 'fill-color': '#3b82f6', 'fill-opacity': 0.05 },
  })
  map.addLayer({
    id: 'radius-outline',
    type: 'line',
    source: 'radius',
    paint: { 'line-color': '#3b82f6', 'line-width': 1.5, 'line-dasharray': [3, 3] },
  })
}

function createCircle(center: [number, number], radiusMeters: number): GeoJSON.Feature {
  const [lon, lat] = center
  const points = 64
  const coords = []
  for (let i = 0; i <= points; i++) {
    const angle = (i / points) * 2 * Math.PI
    const dx = (radiusMeters / 111320) * Math.cos(angle)
    const dy = (radiusMeters / (111320 * Math.cos((lat * Math.PI) / 180))) * Math.sin(angle)
    coords.push([lon + dy, lat + dx])
  }
  return {
    type: 'Feature',
    geometry: { type: 'Polygon', coordinates: [coords] },
    properties: {},
  }
}
