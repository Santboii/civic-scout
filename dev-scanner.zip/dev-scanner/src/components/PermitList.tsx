'use client'

import type { ClassifiedPermit } from '@/lib/permit-classifier'
import { AlertTriangle, AlertCircle, CheckCircle } from 'lucide-react'

interface PermitListProps {
  permits: ClassifiedPermit[]
}

const SEVERITY_CONFIG = {
  red: { icon: AlertTriangle, color: 'text-red-500', bg: 'bg-red-50', label: 'High Impact' },
  yellow: { icon: AlertCircle, color: 'text-yellow-500', bg: 'bg-yellow-50', label: 'Medium Impact' },
  green: { icon: CheckCircle, color: 'text-green-500', bg: 'bg-green-50', label: 'Standard' },
}

export default function PermitList({ permits }: PermitListProps) {
  if (permits.length === 0) {
    return (
      <div className="text-center text-gray-400 text-sm py-8">
        No significant developments found within 2 miles.
      </div>
    )
  }

  const sorted = [...permits].sort((a, b) => {
    const order = { red: 0, yellow: 1, green: 2 }
    return order[a.severity] - order[b.severity]
  })

  return (
    <ul className="space-y-3">
      {sorted.map((permit) => {
        const config = SEVERITY_CONFIG[permit.severity]
        const Icon = config.icon
        return (
          <li key={permit.id} className={`rounded-xl p-3 ${config.bg}`}>
            <div className="flex items-start gap-2">
              <Icon size={16} className={`${config.color} mt-0.5 shrink-0`} />
              <div className="min-w-0">
                <p className="text-sm font-medium text-gray-900 truncate">{permit.address}</p>
                <p className="text-xs text-gray-500 mt-0.5">{permit.permit_type}</p>
                {permit.work_description && (
                  <p className="text-xs text-gray-600 mt-1 line-clamp-2">{permit.work_description}</p>
                )}
                <div className="flex items-center gap-2 mt-1.5">
                  {permit.reported_cost > 0 && (
                    <span className="text-xs text-gray-500">
                      ${(permit.reported_cost / 1e6).toFixed(1)}M
                    </span>
                  )}
                  <span className={`text-xs font-medium ${config.color}`}>{config.label}</span>
                  {permit.zoning_classification && (
                    <span className="text-xs text-gray-400">· {permit.zoning_classification}</span>
                  )}
                </div>
              </div>
            </div>
          </li>
        )
      })}
    </ul>
  )
}
